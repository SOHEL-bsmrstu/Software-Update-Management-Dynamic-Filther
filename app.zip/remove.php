<?php

return [
        "path" => ["app" . DIRECTORY_SEPARATOR . "User.php",]
];
